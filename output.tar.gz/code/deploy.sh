
set -e
echo "-----------------------------"
devrev_id="gaston.donikian@devrev.ai"
echo "Initiating DevRev CLI Authentication for DevRev ID: ${devrev_id}"
devrev profiles authenticate --env dev --org gaston --usr ${devrev_id}
if [ $? -eq 0 ]; then
  echo "Authentication Success!"
else
  echo "Authentication Failed!"
fi
echo "-----------------------------"
echo "Creating compressed archive of all directories..."
npm install && npm run build && npm run package
mv build.tar.gz ../
cd ..

tar -czf output.tar.gz */
if [ $? -eq 0 ]; then
  echo "Compression successful."
else
  echo "Compression failed."
fi
echo "-----------------------------"
echo "Creating a Snap-In package..."

read -p "Enter a value for the --slug option: " slug


name="MadRewards - Create URL from the bot"
description="MadRewards - Create URL from the bot"

package_creation_response=$(devrev snap_in_package create-one --slug $slug --name "$name" --description "$description")

if [[ $package_creation_response == *snap_in_package* ]] && [[ $? -eq 0 ]]; then
  snap_in_package_id=$(echo $package_creation_response | jq -r '.snap_in_package.id')
  echo "Snap In Package created successfully with ID: $snap_in_package_id"
  export snap_in_package_id;
else
  debug_message=$(echo $package_creation_response | jq -r '.debug_message')
  echo "Snap In Package creation failed: $debug_message"
  exit 1
fi
echo "-----------------------------"
echo "Creating a Snap-In version..."

version_creation_response=$(devrev snap_in_version create-one --manifest manifest.yaml --package $snap_in_package_id  --archive build.tar.gz)
echo $version_creation_response
if [[ $version_creation_response == *snap_in_version* ]] && [[ $? -eq 0 ]]; then
  snap_in_version_id=$(echo $version_creation_response | jq -r '.snap_in_version.id')
  echo "Snap In Version created successfully with ID: $snap_in_version_id"
else
  debug_message=$(echo $version_creation_response | jq -r '.debug_message')
  echo "Snap In Version creation failed: $debug_message"
  exit 1
fi
sleep 60
echo "-----------------------------"
echo "Creating a Snap-In draft..."

draft_creation_response=$(devrev snap_in draft --snap_in_version $snap_in_version_id)
if [[ $draft_creation_response == *snap_in* ]] && [[ $? -eq 0 ]]; then
  snap_in_draft_id=$(echo $draft_creation_response | jq -r '.snap_in.id')
  echo "Snap In Draft created successfully with ID: $snap_in_draft_id"
else
  debug_message=$(echo $draft_creation_response | jq -r '.debug_message')
  echo "Snap In Draft creation failed: $debug_message"
  exit 1
fi
echo "-----------------------------"
echo "Updating the Snap In and estabilishing connections..."

devrev snap_in update $snap_in_draft_id
if [[ $? -eq 0 ]]; then
  echo "Snap In updation successful and connections were estabilished"
else
  echo "Snap In updation failed: $debug_message"
  exit 1
fi
echo "-----------------------------"
echo " "
echo " DEPLOYMENT TIME "

echo "Attempting yeet on your Snap In"
#Snap In Deploy
devrev snap_in deploy $snap_in_draft_id --debug --trace -v
if [ $? -eq 0 ]; then
  echo "Snap-in you made was successfully yeeeted on Lambda"
else
  echo "Snap-in deployment failed"
  exit 1
fi
echo "-----------------------------"