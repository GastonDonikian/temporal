import { run } from '../functions/on_work_creation';

describe('Test some function', () => {
  it('Something', () => {
    run([]);
  });
});
